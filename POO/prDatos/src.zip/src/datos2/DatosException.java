package datos2;

public class DatosException  extends Exception{
  public DatosException(){
    super();
  };
  public DatosException(String msg){
    super(msg);
  };
}
