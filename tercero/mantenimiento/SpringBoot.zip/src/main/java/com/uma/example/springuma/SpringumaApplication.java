package com.uma.example.springuma;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SpringumaApplication {
	public static void main(String[] args) {
		SpringApplication.run(SpringumaApplication.class, args);
	}

}
