#include <iostream>
#include <string>

int main(){
  
}