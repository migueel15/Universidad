#include <iostream>

int main() {}
