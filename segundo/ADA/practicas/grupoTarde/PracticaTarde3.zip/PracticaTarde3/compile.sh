javac -cp "towerdefense.jar" net/agsh/towerdefense/strats/*.java
