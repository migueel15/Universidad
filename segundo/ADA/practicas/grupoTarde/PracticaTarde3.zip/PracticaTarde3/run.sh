java -cp ".:towerdefense.jar" Main
