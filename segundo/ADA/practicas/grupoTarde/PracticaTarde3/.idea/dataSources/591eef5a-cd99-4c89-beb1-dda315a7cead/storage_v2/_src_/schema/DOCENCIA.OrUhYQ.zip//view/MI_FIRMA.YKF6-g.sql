create view MI_FIRMA as
select "USUARIO","FECHA","COMENTARIO" from firma where usuario = user
/

