create view SOL_3_21 as
select "PROFESOR1","PROFESOR2" from ej_3_21
/

