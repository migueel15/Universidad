create view SOL_3_23 as
select "DNI" from ej_3_23
/

