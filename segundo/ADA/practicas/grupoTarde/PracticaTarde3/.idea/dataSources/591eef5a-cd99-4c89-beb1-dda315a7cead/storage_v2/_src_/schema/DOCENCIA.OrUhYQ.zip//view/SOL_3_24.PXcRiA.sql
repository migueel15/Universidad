create view SOL_3_24 as
select "DNI" from ej_3_24
/

