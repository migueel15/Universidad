create view SOL_2_16 as
SELECT "CODIGO"
FROM EJ_2_16
/

