create view SOL_6_1 as
select "ASIGNATURA" from ej_6_1
/

