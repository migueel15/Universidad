create view SOL_3_6 as
SELECT nombre, suma from ej_3_6
/

