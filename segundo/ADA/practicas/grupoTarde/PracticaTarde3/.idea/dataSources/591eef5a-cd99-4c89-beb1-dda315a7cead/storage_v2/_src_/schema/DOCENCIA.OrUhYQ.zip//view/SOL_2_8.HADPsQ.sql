create view SOL_2_8 as
SELECT "nombrep1","apellido1p1","apellido2p1","Antiguedad1","nombrep2","apellido1p2","apellido2p2","Antiguedad2" FROM EJ_2_8
/

