create view SOL_2_23 as
SELECT "TESIS","Tramos"
FROM EJ_2_23
/

