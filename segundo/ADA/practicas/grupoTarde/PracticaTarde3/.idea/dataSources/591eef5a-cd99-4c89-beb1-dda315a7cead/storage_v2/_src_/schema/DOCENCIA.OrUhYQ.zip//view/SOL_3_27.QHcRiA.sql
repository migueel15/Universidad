create view SOL_3_27 as
select "profesor","alumno" from ej_3_27
/

