create view SOL_3_2 as
select "DEPARTAMENTO","NUMERO CREDITOS" from ej_3_2
/

