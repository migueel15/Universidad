create view SOL_1_8 as
SELECT "Correos" FROM EJ_1_8
/

