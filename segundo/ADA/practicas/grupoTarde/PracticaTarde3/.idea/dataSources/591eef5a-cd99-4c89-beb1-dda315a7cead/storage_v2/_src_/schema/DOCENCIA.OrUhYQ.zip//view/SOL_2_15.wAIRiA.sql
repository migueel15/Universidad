create view SOL_2_15 as
SELECT "Asignatura","Departamento","CREDITOS","%Prácticos"
FROM EJ_2_15
/

