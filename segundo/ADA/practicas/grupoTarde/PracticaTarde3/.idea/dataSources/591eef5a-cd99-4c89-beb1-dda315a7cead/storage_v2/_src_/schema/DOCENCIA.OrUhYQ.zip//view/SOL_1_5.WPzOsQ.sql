create view SOL_1_5 as
SELECT "NOMBRE","CREDITOS","Teoricos (%)","Practicos (%)" FROM EJ_1_5
/

