create view SOL_2_14 as
SELECT "Asignatura","Materia","Profesor","CARGA_CREDITOS"
FROM EJ_2_14
/

