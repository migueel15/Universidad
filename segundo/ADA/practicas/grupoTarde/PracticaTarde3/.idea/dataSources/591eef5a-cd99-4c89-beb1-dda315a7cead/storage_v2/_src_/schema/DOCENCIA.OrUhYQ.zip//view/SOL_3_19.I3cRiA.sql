create view SOL_3_19 as
select "NOMBRE","APELLIDO1","APELLIDO2" from ej_3_19
/

