create view SOL_2_6 as
SELECT "Nombre 1","Edad 1","Nombre 2","Edad 2" FROM EJ_2_6
/

