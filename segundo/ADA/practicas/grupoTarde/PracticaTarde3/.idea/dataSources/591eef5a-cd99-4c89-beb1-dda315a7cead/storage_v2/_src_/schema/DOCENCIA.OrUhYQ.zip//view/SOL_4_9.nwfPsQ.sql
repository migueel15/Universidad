create view SOL_4_9 as
SELECT provincia, mujeres  from ej_4_9
/

