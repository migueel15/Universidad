create view SOL_3_16 as
select "ID" from ej_3_16
/

