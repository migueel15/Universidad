create view SOL_3_3 as
select "CURSO","NUMERO ALUMNOS" from ej_3_3
/

