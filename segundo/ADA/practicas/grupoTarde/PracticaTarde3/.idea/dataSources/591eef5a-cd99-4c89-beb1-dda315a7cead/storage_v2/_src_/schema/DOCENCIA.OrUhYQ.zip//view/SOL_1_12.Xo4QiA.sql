create view SOL_1_12 as
SELECT "NOMBRE" FROM EJ_1_12
/

