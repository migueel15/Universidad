create view SOL_3_15 as
select "NOMBRE","APELLIDO1","APELLIDO2" from ej_3_15
/

