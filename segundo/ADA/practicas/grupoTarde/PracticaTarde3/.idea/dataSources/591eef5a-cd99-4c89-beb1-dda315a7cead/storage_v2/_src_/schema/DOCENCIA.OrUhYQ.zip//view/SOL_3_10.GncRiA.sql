create view SOL_3_10 as
select "DEPARTAMENTO","ASIGNATURA" from ej_3_10
/

