create view SOL_4_5 as
select alumno1,alumno2 from ej_4_5
/

