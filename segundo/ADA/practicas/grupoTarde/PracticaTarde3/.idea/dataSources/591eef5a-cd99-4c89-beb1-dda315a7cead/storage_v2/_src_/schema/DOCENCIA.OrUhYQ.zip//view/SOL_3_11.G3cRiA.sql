create view SOL_3_11 as
select "ASIGNATURA","ALUMNO","FECHA DE NACIMIENTO" from ej_3_11
/

