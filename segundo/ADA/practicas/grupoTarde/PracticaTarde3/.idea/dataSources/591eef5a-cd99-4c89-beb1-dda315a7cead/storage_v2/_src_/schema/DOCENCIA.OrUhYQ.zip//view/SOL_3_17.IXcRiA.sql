create view SOL_3_17 as
select "NOMBRE" from ej_3_17
/

