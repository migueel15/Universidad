create view SOL_4_3 as
select "alumno_1","alumno_2" from ej_4_3
/

