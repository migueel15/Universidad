create view SOL_3_12 as
select "PROFESOR","CREDITOS" from ej_3_12
/

