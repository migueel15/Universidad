create view SOL_3_28 as
select "ASIGNATURA","ALUMNO" from ej_3_28
/

