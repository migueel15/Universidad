create view SOL_3_29 as
select "CODIGO","numero profesores" from ej_3_29
/

