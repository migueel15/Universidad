create view SOL_3_4 as
select "DESPACHO","TOTAL CREDITOS" from ej_3_4
/

