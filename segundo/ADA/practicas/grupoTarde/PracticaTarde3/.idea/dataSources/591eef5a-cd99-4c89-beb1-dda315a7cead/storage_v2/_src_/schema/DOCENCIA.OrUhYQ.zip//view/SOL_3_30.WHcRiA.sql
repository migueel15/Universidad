create view SOL_3_30 as
select "profesor" from ej_3_30
/

