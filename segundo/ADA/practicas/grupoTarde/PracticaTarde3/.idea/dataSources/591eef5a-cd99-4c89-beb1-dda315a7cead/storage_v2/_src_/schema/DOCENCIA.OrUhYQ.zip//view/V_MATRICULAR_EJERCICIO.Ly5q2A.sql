create view V_MATRICULAR_EJERCICIO as
select alumno, asignatura, grupo,curso,calificacion from matricular_ejercicio where usuario  = user
/

