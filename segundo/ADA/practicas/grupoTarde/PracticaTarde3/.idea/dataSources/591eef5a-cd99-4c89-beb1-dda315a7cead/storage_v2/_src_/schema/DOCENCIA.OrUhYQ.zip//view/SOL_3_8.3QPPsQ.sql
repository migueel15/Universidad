create view SOL_3_8 as
select "ALUMNO","CODIGO","NOMBRE" from ej_3_8
/

