create view SOL_3_1 as
select "DEPARTAMENTO","NUMERO PROFESORES" from ej_3_1
/

