create view SOL_3_7 as
SELECT departamento, profesor from ej_3_7
/

