create view SOL_4_8 as
SELECT nombre, apellido1, apellido2, asignatura from ej_4_8
/

