create view SOL_3_5 as
select "ASIGNATURA","PORCENTAGE" from ej_3_5
/

