create view SOL_3_18 as
select "NOMBRE" from ej_3_18
/

