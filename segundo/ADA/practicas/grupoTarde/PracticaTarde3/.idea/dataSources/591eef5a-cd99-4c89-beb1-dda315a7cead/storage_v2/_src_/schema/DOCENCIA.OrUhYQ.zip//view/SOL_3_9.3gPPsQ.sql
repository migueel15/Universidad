create view SOL_3_9 as
select "DEPARTAMENTO","PROFESOR" from ej_3_9
/

