create view SOL_2_9 as
SELECT "ELLA","EL" FROM EJ_2_9
/

