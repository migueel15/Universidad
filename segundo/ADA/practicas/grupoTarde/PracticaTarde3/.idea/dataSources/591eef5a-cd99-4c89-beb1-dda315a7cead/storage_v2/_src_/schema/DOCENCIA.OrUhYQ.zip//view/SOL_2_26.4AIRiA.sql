create view SOL_2_26 as
SELECT "NOMBRE","ID"
FROM EJ_2_26
/

