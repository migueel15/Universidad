create view SOL_4_4 as
select "profesor_1","profesor_2" from ej_4_4
/

