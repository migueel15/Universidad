create view SOL_2_10 as
SELECT "Asignatura 1","Asignatura 2","Asignatura 3","Materia" FROM EJ_2_10
/

