create view SOL_2_7 as
SELECT "Primer apellido","Segundo Apellido" FROM EJ_2_7
/

