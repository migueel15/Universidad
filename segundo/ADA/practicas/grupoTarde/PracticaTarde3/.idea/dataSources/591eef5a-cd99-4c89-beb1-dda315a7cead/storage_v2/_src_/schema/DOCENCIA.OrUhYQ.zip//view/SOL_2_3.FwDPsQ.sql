create view SOL_2_3 as
SELECT "NOMBRE","APELLIDO1","APELLIDO2","ANTIGUEDAD","Se cumple una semana" FROM EJ_2_3
/

