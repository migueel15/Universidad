create view SOL_6_2 as
select "ALUMNO" from ej_6_2
/

