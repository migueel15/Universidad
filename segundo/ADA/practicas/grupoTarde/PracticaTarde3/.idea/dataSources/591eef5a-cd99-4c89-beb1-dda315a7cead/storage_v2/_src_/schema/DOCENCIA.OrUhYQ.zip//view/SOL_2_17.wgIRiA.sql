create view SOL_2_17 as
SELECT "EMAIL"
FROM EJ_2_17
/

