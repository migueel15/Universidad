create view SOL_3_14 as
select "PROFESOR","CREDITOS" from ej_3_14
/

