create view SOL_3_22 as
SELECT nombre from ej_3_22
/

