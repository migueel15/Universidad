create view SOL_4_7 as
SELECT provincia, municipio, alumnos from ej_4_7
/

