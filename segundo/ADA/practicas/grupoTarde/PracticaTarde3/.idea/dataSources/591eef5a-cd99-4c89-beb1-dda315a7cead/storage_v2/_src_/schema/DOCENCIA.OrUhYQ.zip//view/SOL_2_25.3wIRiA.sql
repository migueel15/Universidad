create view SOL_2_25 as
SELECT "asignatura","CURSO","GRUPO","NOMBRE","APELLIDO1"
FROM EJ_2_25
/

