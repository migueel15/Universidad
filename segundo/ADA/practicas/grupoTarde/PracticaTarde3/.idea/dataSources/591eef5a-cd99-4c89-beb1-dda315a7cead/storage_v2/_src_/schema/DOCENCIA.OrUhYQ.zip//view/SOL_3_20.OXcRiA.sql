create view SOL_3_20 as
select "PROFESOR1","PROFESOR2" from ej_3_20
/

