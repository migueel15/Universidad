create view SOL_2_29 as
SELECT "NOMBRE","CODIGO"    
FROM EJ_2_29
/

