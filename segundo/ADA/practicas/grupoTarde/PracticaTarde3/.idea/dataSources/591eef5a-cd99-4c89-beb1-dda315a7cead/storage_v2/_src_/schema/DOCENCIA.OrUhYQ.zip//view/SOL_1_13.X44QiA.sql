create view SOL_1_13 as
SELECT "NOMBRE","Creditos" FROM EJ_1_13
/

