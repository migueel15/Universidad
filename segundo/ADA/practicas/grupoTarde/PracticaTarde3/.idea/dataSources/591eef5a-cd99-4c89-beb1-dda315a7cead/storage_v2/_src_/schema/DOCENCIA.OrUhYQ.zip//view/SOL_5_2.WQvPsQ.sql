create view SOL_5_2 as
select "NOMBRE","APELLIDO1","APELLIDO2","DIRECTOR_TESIS" from ej_5_2
/

