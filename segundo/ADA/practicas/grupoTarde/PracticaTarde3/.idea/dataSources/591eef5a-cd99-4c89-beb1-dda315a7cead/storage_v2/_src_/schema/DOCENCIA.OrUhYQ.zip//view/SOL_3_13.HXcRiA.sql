create view SOL_3_13 as
select "DEPARTAMENTO" from ej_3_13
/

