create view SOL_3_26 as
select "DEPARTAMENTO","creditos" from ej_3_26
/

