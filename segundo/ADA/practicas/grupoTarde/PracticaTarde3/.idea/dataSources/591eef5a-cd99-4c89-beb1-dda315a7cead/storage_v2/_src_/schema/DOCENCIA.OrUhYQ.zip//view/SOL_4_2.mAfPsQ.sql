create view SOL_4_2 as
select "DNI" from ej_4_2
/

