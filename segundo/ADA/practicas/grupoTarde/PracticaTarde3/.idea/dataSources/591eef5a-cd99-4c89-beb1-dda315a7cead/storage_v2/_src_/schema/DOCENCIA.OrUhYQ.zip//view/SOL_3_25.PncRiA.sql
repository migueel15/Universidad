create view SOL_3_25 as
select "CODIGO","DEPARTAMENTO" from ej_3_25
/

