create view SOL_4_1 as
select "PROFESOR_1","PROFESOR_2" from ej_4_1
/

